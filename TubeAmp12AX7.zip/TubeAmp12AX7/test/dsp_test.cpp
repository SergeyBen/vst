// Проверка DSP-ядра без JUCE: g++ -O2 -std=c++17 dsp_test.cpp -o dsp_test
#include "../Source/TubeDSP.h"
#include <cstdio>
#include <vector>

using namespace tube;

static double goertzel (const std::vector<double>& x, double fs, double f)
{
    const double w = 2.0 * kPi * f / fs, c = 2.0 * std::cos (w);
    double s1 = 0, s2 = 0;
    for (double v : x) { const double s = v + c * s1 - s2; s2 = s1; s1 = s; }
    return std::sqrt (s1 * s1 + s2 * s2 - c * s1 * s2) * 2.0 / (double) x.size();
}

int main()
{
    const double fsBase = 48000.0, fs = fsBase * 4.0, f0 = 1000.0;
    const auto& t = TriodeTable::get();
    std::printf ("Vp(покой)=%.1f В, полуразмах=%.1f В, Vp(vin=-3В)=%.1f, Vp(vin=+3В)=%.1f\n",
                 t.quiescent(), t.halfSwing(), t.plate (-3.0), t.plate (3.0));

    std::printf ("\nвход(dB FS) вход.гейн  выход(пик)  H1(dB)  H2(dB отн.)  H3(dB отн.)  нет NaN\n");
    for (double inGainDb : { 0.0, 12.0, 24.0, 36.0 })
    for (double ampDb : { -40.0, -20.0, -6.0 })
    {
        const double amp = std::pow (10.0, ampDb / 20.0) * std::pow (10.0, inGainDb / 20.0);
        AmpChannel ch; ch.prepare (fs);
        std::vector<double> y;
        bool ok = true; double peak = 0;
        const int N = (int) (fs * 0.5);
        for (int n = 0; n < N; ++n)
        {
            const double v = ch.process (amp * std::sin (2 * kPi * f0 * n / fs));
            if (! std::isfinite (v)) ok = false;
            if (n >= N / 2) { y.push_back (v); peak = std::max (peak, std::abs (v)); }
        }
        const double h1 = goertzel (y, fs, f0), h2 = goertzel (y, fs, 2 * f0), h3 = goertzel (y, fs, 3 * f0);
        std::printf ("%6.0f      %6.0f dB   %8.4f   %6.1f   %8.1f    %8.1f      %s\n",
                     ampDb, inGainDb, peak, 20 * std::log10 (h1 + 1e-12),
                     20 * std::log10 (h2 / h1 + 1e-12), 20 * std::log10 (h3 / h1 + 1e-12), ok ? "ok" : "NaN!");
    }

    // Обрез НЧ
    std::printf ("\nОбрез НЧ (80 Гц): ослабление на частотах\n");
    for (double f : { 20.0, 40.0, 80.0, 160.0, 1000.0 })
    {
        Biquad b; b.setHighpass (fsBase, 80.0);
        std::vector<double> y;
        for (int n = 0; n < (int) fsBase; ++n)
        {
            const double v = b.process (std::sin (2 * kPi * f * n / fsBase));
            if (n > (int) fsBase / 2) y.push_back (v);
        }
        std::printf ("  %6.0f Гц : %6.1f dB\n", f, 20 * std::log10 (goertzel (y, fsBase, f) + 1e-12));
    }

    // Тишина на входе -> тишина на выходе (нет щелчка при старте)
    AmpChannel ch; ch.prepare (fs);
    double mx = 0;
    for (int n = 0; n < 20000; ++n) mx = std::max (mx, std::abs (ch.process (0.0)));
    std::printf ("\nмакс. на выходе при нулевом входе: %.3g\n", mx);
}
