#pragma once

#include <array>
#include <memory>
#include <juce_audio_processors/juce_audio_processors.h>
#include <juce_dsp/juce_dsp.h>

#include "TubeDSP.h"

namespace ParamIDs
{
    inline constexpr const char* input  = "input";   // дБ
    inline constexpr const char* lowcut = "lowcut";  // Гц
    inline constexpr const char* output = "output";  // дБ
}

class TubeAmpProcessor : public juce::AudioProcessor
{
public:
    TubeAmpProcessor();
    ~TubeAmpProcessor() override = default;

    void prepareToPlay (double sampleRate, int samplesPerBlock) override;
    void releaseResources() override {}
    bool isBusesLayoutSupported (const BusesLayout& layouts) const override;
    void processBlock (juce::AudioBuffer<float>&, juce::MidiBuffer&) override;

    juce::AudioProcessorEditor* createEditor() override;
    bool hasEditor() const override { return true; }

    const juce::String getName() const override { return "Tube Amp 12AX7"; }
    bool acceptsMidi() const override { return false; }
    bool producesMidi() const override { return false; }
    bool isMidiEffect() const override { return false; }
    double getTailLengthSeconds() const override { return 0.0; }

    int getNumPrograms() override { return 1; }
    int getCurrentProgram() override { return 0; }
    void setCurrentProgram (int) override {}
    const juce::String getProgramName (int) override { return {}; }
    void changeProgramName (int, const juce::String&) override {}

    void getStateInformation (juce::MemoryBlock& destData) override;
    void setStateInformation (const void* data, int sizeInBytes) override;

    juce::AudioProcessorValueTreeState apvts;

private:
    static juce::AudioProcessorValueTreeState::ParameterLayout createLayout();

    static constexpr int kOversamplingStages = 2;                 // 2^2 = 4x
    static constexpr double kOversamplingFactor = 4.0;
    static constexpr int kMaxChannels = 2;

    std::unique_ptr<juce::dsp::Oversampling<float>> oversampling;
    std::array<tube::AmpChannel, kMaxChannels> amps;
    std::array<tube::Biquad, kMaxChannels> lowCut;

    juce::SmoothedValue<float> inputGain, outputGain;
    std::vector<float> gainBuffer;

    std::atomic<float>* inputParam  = nullptr;
    std::atomic<float>* lowcutParam = nullptr;
    std::atomic<float>* outputParam = nullptr;

    double sampleRateHz = 44100.0;
    int maxBlock = 512;
    float lastCutoff = -1.0f;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TubeAmpProcessor)
};
