#include "PluginEditor.h"

TubeAmpEditor::TubeAmpEditor (TubeAmpProcessor& p)
    : AudioProcessorEditor (&p), processor (p)
{
    setLookAndFeel (&lookAndFeel);

    setupKnob (inputKnob,  "INPUT",   ParamIDs::input,  " dB", 1);
    setupKnob (lowCutKnob, "LOW CUT", ParamIDs::lowcut, " Hz", 0);
    setupKnob (outputKnob, "OUTPUT",  ParamIDs::output, " dB", 1);

    setSize (480, 280);
}

TubeAmpEditor::~TubeAmpEditor()
{
    setLookAndFeel (nullptr);
}

void TubeAmpEditor::setupKnob (Knob& k, const juce::String& title, const juce::String& paramID,
                               const juce::String& suffix, int decimals)
{
    k.slider.setSliderStyle (juce::Slider::RotaryHorizontalVerticalDrag);
    k.slider.setRotaryParameters (juce::MathConstants<float>::pi * 1.2f,
                                  juce::MathConstants<float>::pi * 2.8f, true);
    k.slider.setTextBoxStyle (juce::Slider::TextBoxBelow, false, 90, 22);
    k.slider.setTextValueSuffix (suffix);
    k.slider.setNumDecimalPlacesToDisplay (decimals);
    addAndMakeVisible (k.slider);

    k.label.setText (title, juce::dontSendNotification);
    k.label.setJustificationType (juce::Justification::centred);
    k.label.setFont (juce::FontOptions (14.0f, juce::Font::bold));
    k.label.setColour (juce::Label::textColourId, juce::Colour (0xffd9b26a));
    addAndMakeVisible (k.label);

    k.attachment = std::make_unique<juce::AudioProcessorValueTreeState::SliderAttachment> (
        processor.apvts, paramID, k.slider);
}

void TubeAmpEditor::paint (juce::Graphics& g)
{
    g.setGradientFill (juce::ColourGradient (juce::Colour (0xff2b221b), 0.0f, 0.0f,
                                             juce::Colour (0xff120e0b), 0.0f, (float) getHeight(), false));
    g.fillAll();

    g.setColour (juce::Colour (0xff8a6a3a));
    g.drawRect (getLocalBounds().reduced (6), 2);

    g.setColour (juce::Colour (0xfff0e2c0));
    g.setFont (juce::FontOptions (22.0f, juce::Font::bold));
    g.drawText ("TUBE AMP  -  12AX7", 0, 14, getWidth(), 30, juce::Justification::centred);
}

void TubeAmpEditor::resized()
{
    auto area = getLocalBounds().reduced (20);
    area.removeFromTop (44);

    const int w = area.getWidth() / 3;
    for (auto* k : { &inputKnob, &lowCutKnob, &outputKnob })
    {
        auto col = area.removeFromLeft (w);
        k->label.setBounds (col.removeFromTop (22));
        k->slider.setBounds (col);
    }
}
