#include "PluginProcessor.h"
#include "PluginEditor.h"

TubeAmpProcessor::TubeAmpProcessor()
    : AudioProcessor (BusesProperties()
                          .withInput ("Input", juce::AudioChannelSet::stereo(), true)
                          .withOutput ("Output", juce::AudioChannelSet::stereo(), true)),
      apvts (*this, nullptr, "PARAMS", createLayout())
{
    inputParam  = apvts.getRawParameterValue (ParamIDs::input);
    lowcutParam = apvts.getRawParameterValue (ParamIDs::lowcut);
    outputParam = apvts.getRawParameterValue (ParamIDs::output);
}

juce::AudioProcessorValueTreeState::ParameterLayout TubeAmpProcessor::createLayout()
{
    using namespace juce;
    AudioProcessorValueTreeState::ParameterLayout layout;

    layout.add (std::make_unique<AudioParameterFloat> (
        ParameterID { ParamIDs::input, 1 }, "Input",
        NormalisableRange<float> (-12.0f, 36.0f, 0.1f), 12.0f,
        AudioParameterFloatAttributes().withLabel ("dB")));

    NormalisableRange<float> lowRange (20.0f, 500.0f, 1.0f);
    lowRange.setSkewForCentre (100.0f);
    layout.add (std::make_unique<AudioParameterFloat> (
        ParameterID { ParamIDs::lowcut, 1 }, "Low Cut",
        lowRange, 80.0f,
        AudioParameterFloatAttributes().withLabel ("Hz")));

    layout.add (std::make_unique<AudioParameterFloat> (
        ParameterID { ParamIDs::output, 1 }, "Output",
        NormalisableRange<float> (-36.0f, 12.0f, 0.1f), 0.0f,
        AudioParameterFloatAttributes().withLabel ("dB")));

    return layout;
}

bool TubeAmpProcessor::isBusesLayoutSupported (const BusesLayout& layouts) const
{
    const auto& in  = layouts.getMainInputChannelSet();
    const auto& out = layouts.getMainOutputChannelSet();

    if (in != out)
        return false;

    return in == juce::AudioChannelSet::mono() || in == juce::AudioChannelSet::stereo();
}

void TubeAmpProcessor::prepareToPlay (double sampleRate, int samplesPerBlock)
{
    sampleRateHz = sampleRate;
    maxBlock = juce::jmax (1, samplesPerBlock);

    const int numCh = juce::jlimit (1, kMaxChannels, getTotalNumInputChannels());
    oversampling = std::make_unique<juce::dsp::Oversampling<float>> (
        (size_t) numCh, (size_t) kOversamplingStages,
        juce::dsp::Oversampling<float>::filterHalfBandPolyphaseIIR,
        true,    // максимальное качество
        true);   // целочисленная задержка
    oversampling->initProcessing ((size_t) maxBlock);
    setLatencySamples (juce::roundToInt (oversampling->getLatencyInSamples()));

    for (auto& a : amps) a.prepare (sampleRate * kOversamplingFactor);
    for (auto& f : lowCut) f.reset();
    lastCutoff = -1.0f;

    inputGain.reset (sampleRate, 0.02);
    outputGain.reset (sampleRate, 0.02);
    inputGain.setCurrentAndTargetValue (juce::Decibels::decibelsToGain (inputParam->load()));
    outputGain.setCurrentAndTargetValue (juce::Decibels::decibelsToGain (outputParam->load()));

    gainBuffer.assign ((size_t) maxBlock, 1.0f);
}

void TubeAmpProcessor::processBlock (juce::AudioBuffer<float>& buffer, juce::MidiBuffer&)
{
    juce::ScopedNoDenormals noDenormals;

    const int numSamples = buffer.getNumSamples();
    const int numCh = juce::jmin (buffer.getNumChannels(), kMaxChannels);

    for (int ch = getTotalNumInputChannels(); ch < getTotalNumOutputChannels(); ++ch)
        buffer.clear (ch, 0, numSamples);

    if (oversampling == nullptr || numCh == 0)
        return;

    inputGain.setTargetValue (juce::Decibels::decibelsToGain (inputParam->load()));
    outputGain.setTargetValue (juce::Decibels::decibelsToGain (outputParam->load()));

    const float cutoff = lowcutParam->load();
    if (cutoff != lastCutoff)
    {
        for (auto& f : lowCut) f.setHighpass (sampleRateHz, (double) cutoff);
        lastCutoff = cutoff;
    }

    juce::dsp::AudioBlock<float> fullBlock (buffer);

    int pos = 0;
    while (pos < numSamples)
    {
        const int n = juce::jmin (numSamples - pos, maxBlock);
        if ((int) gainBuffer.size() < n) gainBuffer.resize ((size_t) n);

        // 1) входная громкость + обрез НЧ (на основной частоте)
        for (int i = 0; i < n; ++i) gainBuffer[(size_t) i] = inputGain.getNextValue();

        for (int ch = 0; ch < numCh; ++ch)
        {
            float* d = buffer.getWritePointer (ch) + pos;
            for (int i = 0; i < n; ++i)
                d[i] = (float) lowCut[(size_t) ch].process ((double) (d[i] * gainBuffer[(size_t) i]));
        }

        // 2) две лампы 12AX7 на частоте 4x
        auto sub = fullBlock.getSubBlock ((size_t) pos, (size_t) n);
        auto up = oversampling->processSamplesUp (sub);

        for (int ch = 0; ch < numCh; ++ch)
        {
            float* d = up.getChannelPointer ((size_t) ch);
            for (size_t i = 0; i < up.getNumSamples(); ++i)
                d[i] = (float) amps[(size_t) ch].process ((double) d[i]);
        }

        oversampling->processSamplesDown (sub);

        // 3) выходная громкость
        for (int i = 0; i < n; ++i) gainBuffer[(size_t) i] = outputGain.getNextValue();

        for (int ch = 0; ch < numCh; ++ch)
        {
            float* d = buffer.getWritePointer (ch) + pos;
            for (int i = 0; i < n; ++i)
                d[i] *= gainBuffer[(size_t) i];
        }

        pos += n;
    }
}

juce::AudioProcessorEditor* TubeAmpProcessor::createEditor()
{
    return new TubeAmpEditor (*this);
}

void TubeAmpProcessor::getStateInformation (juce::MemoryBlock& destData)
{
    auto state = apvts.copyState();
    if (auto xml = state.createXml())
        copyXmlToBinary (*xml, destData);
}

void TubeAmpProcessor::setStateInformation (const void* data, int sizeInBytes)
{
    if (auto xml = getXmlFromBinary (data, sizeInBytes))
        if (xml->hasTagName (apvts.state.getType()))
            apvts.replaceState (juce::ValueTree::fromXml (*xml));
}

juce::AudioProcessor* JUCE_CALLTYPE createPluginFilter()
{
    return new TubeAmpProcessor();
}
