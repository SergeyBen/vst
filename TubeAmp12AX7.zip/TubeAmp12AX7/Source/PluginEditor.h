#pragma once

#include "PluginProcessor.h"

// Ручка в винтажном стиле
class KnobLookAndFeel : public juce::LookAndFeel_V4
{
public:
    KnobLookAndFeel()
    {
        setColour (juce::Slider::textBoxTextColourId, juce::Colour (0xfff0e2c0));
        setColour (juce::Slider::textBoxOutlineColourId, juce::Colours::transparentBlack);
        setColour (juce::Slider::textBoxBackgroundColourId, juce::Colours::transparentBlack);
    }

    void drawRotarySlider (juce::Graphics& g, int x, int y, int width, int height,
                           float sliderPos, float startAngle, float endAngle,
                           juce::Slider&) override
    {
        auto bounds = juce::Rectangle<int> (x, y, width, height).toFloat().reduced (8.0f);
        const float radius = juce::jmin (bounds.getWidth(), bounds.getHeight()) * 0.5f;
        const auto centre = bounds.getCentre();
        const float angle = startAngle + sliderPos * (endAngle - startAngle);

        // шкала
        juce::Path track;
        track.addCentredArc (centre.x, centre.y, radius, radius, 0.0f, startAngle, endAngle, true);
        g.setColour (juce::Colour (0xff3a3026));
        g.strokePath (track, juce::PathStrokeType (3.5f, juce::PathStrokeType::curved,
                                                   juce::PathStrokeType::rounded));

        juce::Path value;
        value.addCentredArc (centre.x, centre.y, radius, radius, 0.0f, startAngle, angle, true);
        g.setColour (juce::Colour (0xffff9a2e));
        g.strokePath (value, juce::PathStrokeType (3.5f, juce::PathStrokeType::curved,
                                                   juce::PathStrokeType::rounded));

        // корпус ручки
        const float body = radius * 0.78f;
        g.setColour (juce::Colours::black.withAlpha (0.45f));
        g.fillEllipse (centre.x - body + 2.0f, centre.y - body + 4.0f, body * 2.0f, body * 2.0f);

        g.setGradientFill (juce::ColourGradient (juce::Colour (0xff6a5f55), centre.x - body * 0.5f, centre.y - body * 0.7f,
                                                 juce::Colour (0xff17130f), centre.x + body * 0.6f, centre.y + body * 0.8f,
                                                 false));
        g.fillEllipse (centre.x - body, centre.y - body, body * 2.0f, body * 2.0f);

        g.setColour (juce::Colour (0xff0d0a08));
        g.drawEllipse (centre.x - body, centre.y - body, body * 2.0f, body * 2.0f, 1.5f);

        // указатель
        juce::Path pointer;
        pointer.addRoundedRectangle (-2.5f, -body + 3.0f, 5.0f, body * 0.5f, 2.0f);
        g.setColour (juce::Colour (0xfff0e2c0));
        g.fillPath (pointer, juce::AffineTransform::rotation (angle).translated (centre.x, centre.y));
    }
};

class TubeAmpEditor : public juce::AudioProcessorEditor
{
public:
    explicit TubeAmpEditor (TubeAmpProcessor&);
    ~TubeAmpEditor() override;

    void paint (juce::Graphics&) override;
    void resized() override;

private:
    struct Knob
    {
        juce::Slider slider;
        juce::Label label;
        std::unique_ptr<juce::AudioProcessorValueTreeState::SliderAttachment> attachment;
    };

    void setupKnob (Knob& k, const juce::String& title, const juce::String& paramID,
                    const juce::String& suffix, int decimals);

    TubeAmpProcessor& processor;
    KnobLookAndFeel lookAndFeel;
    Knob inputKnob, lowCutKnob, outputKnob;

    JUCE_DECLARE_NON_COPYABLE_WITH_LEAK_DETECTOR (TubeAmpEditor)
};
