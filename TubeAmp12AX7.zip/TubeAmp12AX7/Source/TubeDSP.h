#pragma once
// Независимое от JUCE DSP-ядро: модель двух каскадов на триоде 12AX7.
// Модель триода: Norman Koren (параметры 12AX7), анодная нагрузка решается
// заранее в таблицу Vp = F(Vg), поэтому на каждый сэмпл остаётся одна интерполяция.

#include <algorithm>
#include <cmath>
#include <vector>

namespace tube
{
constexpr double kPi = 3.14159265358979323846;

// ---------------------------------------------------------------- фильтры

// 2-го порядка, Баттерворт, фильтр высоких частот (обрез НЧ)
class Biquad
{
public:
    void setHighpass (double fs, double fc, double q = 0.70710678118)
    {
        fc = std::min (std::max (fc, 1.0), fs * 0.45);
        const double w0 = 2.0 * kPi * fc / fs;
        const double cs = std::cos (w0), sn = std::sin (w0);
        const double alpha = sn / (2.0 * q);
        const double a0 = 1.0 + alpha;
        b0 = (1.0 + cs) * 0.5 / a0;
        b1 = -(1.0 + cs) / a0;
        b2 = b0;
        a1 = -2.0 * cs / a0;
        a2 = (1.0 - alpha) / a0;
    }

    void reset() { z1 = z2 = 0.0; }

    double process (double x)
    {
        const double y = b0 * x + z1;
        z1 = b1 * x - a1 * y + z2;
        z2 = b2 * x - a2 * y;
        return y;
    }

private:
    double b0 = 1, b1 = 0, b2 = 0, a1 = 0, a2 = 0, z1 = 0, z2 = 0;
};

// Разделительный конденсатор (снимает постоянную составляющую)
class OnePoleHP
{
public:
    void setCutoff (double fs, double fc) { a = std::exp (-2.0 * kPi * fc / fs); }
    void reset() { x1 = y1 = 0.0; }
    double process (double x)
    {
        const double y = a * (y1 + x - x1);
        x1 = x;
        y1 = y;
        return y;
    }

private:
    double a = 0.999, x1 = 0, y1 = 0;
};

// Ёмкость Миллера / паразитные ёмкости: лёгкий спад ВЧ
class OnePoleLP
{
public:
    void setCutoff (double fs, double fc) { b = 1.0 - std::exp (-2.0 * kPi * fc / fs); }
    void reset() { z = 0.0; }
    double process (double x)
    {
        z += b * (x - z);
        return z;
    }

private:
    double b = 1.0, z = 0.0;
};

// ---------------------------------------------------------------- триод

class TriodeTable
{
public:
    // Источник питания, анодная нагрузка, напряжение смещения катода
    static constexpr double B  = 250.0;
    static constexpr double Rp = 100000.0;
    static constexpr double Vk = 1.5;

    static const TriodeTable& get()
    {
        static const TriodeTable instance;
        return instance;
    }

    // vin - напряжение сигнала на сетке (вольты), возвращает напряжение на аноде
    double plate (double vin) const
    {
        double vg = vin - Vk;

        // Сеточный ток: сетка не может уйти заметно выше катода
        if (vg > 0.0)
            vg = kGridClamp * std::tanh (vg / kGridClamp);

        if (vg <= vgMin) return table.front();

        const double pos = (vg - vgMin) * invStep;
        const size_t i = (size_t) pos;
        if (i + 1 >= table.size()) return table.back();
        const double frac = pos - (double) i;
        return table[i] + frac * (table[i + 1] - table[i]);
    }

    double quiescent() const { return plate (0.0); }
    double halfSwing() const { return 0.5 * (table.front() - table.back()); }

private:
    static constexpr double kGridClamp = 0.5;
    static constexpr size_t kSize = 8192;

    double vgMin = -8.0, vgMax = kGridClamp, invStep = 1.0;
    std::vector<double> table;

    // Koren, 12AX7: mu=100, Ex=1.4, Kg1=1060, Kp=600, Kvb=300
    static double plateCurrent (double vg, double vp)
    {
        constexpr double mu = 100.0, ex = 1.4, kg1 = 1060.0, kp = 600.0, kvb = 300.0;
        if (vp <= 0.0) return 0.0;
        const double arg = kp * (1.0 / mu + vg / std::sqrt (kvb + vp * vp));
        const double softplus = arg > 30.0 ? arg : std::log1p (std::exp (arg));
        const double e1 = vp / kp * softplus;
        return e1 > 0.0 ? std::pow (e1, ex) / kg1 : 0.0;
    }

    // Vp + Rp*Ip(Vg,Vp) = B  ->  метод деления отрезка (функция монотонна)
    static double solvePlate (double vg)
    {
        double lo = 0.0, hi = B;
        for (int i = 0; i < 60; ++i)
        {
            const double mid = 0.5 * (lo + hi);
            if (mid + Rp * plateCurrent (vg, mid) - B > 0.0) hi = mid; else lo = mid;
        }
        return 0.5 * (lo + hi);
    }

    TriodeTable()
    {
        table.resize (kSize);
        const double step = (vgMax - vgMin) / (double) (kSize - 1);
        invStep = 1.0 / step;
        for (size_t i = 0; i < kSize; ++i)
            table[i] = solvePlate (vgMin + step * (double) i);
    }
};

// ---------------------------------------------------------------- усилитель

// Один канал: триод -> разделительная ёмкость -> делитель -> триод.
// Работает на частоте оверсэмплинга.
class AmpChannel
{
public:
    static constexpr double kFullScaleVolts = 1.0;   // 0 dBFS = 1 В на входе первой лампы
    static constexpr double kInterstage     = 0.05;  // делитель между каскадами
    static constexpr double kOutputPeak     = 0.5;   // полное насыщение ~ -6 dBFS

    void prepare (double fsOversampled)
    {
        coupling1.setCutoff (fsOversampled, 25.0);
        coupling2.setCutoff (fsOversampled, 25.0);
        miller1.setCutoff (fsOversampled, 14000.0);
        miller2.setCutoff (fsOversampled, 11000.0);
        reset();
    }

    void reset()
    {
        coupling1.reset(); coupling2.reset();
        miller1.reset();   miller2.reset();
    }

    double process (double x)
    {
        const auto& t = TriodeTable::get();
        const double q = t.quiescent();
        const double norm = kOutputPeak / t.halfSwing();

        double p = t.plate (x * kFullScaleVolts) - q;
        p = coupling1.process (miller1.process (p));

        p = t.plate (p * kInterstage) - q;
        p = coupling2.process (miller2.process (p));

        return p * norm;
    }

private:
    OnePoleHP coupling1, coupling2;
    OnePoleLP miller1, miller2;
};

} // namespace tube
